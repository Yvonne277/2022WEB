// ==================== Setting and Configure ====================
// Import express
const express = require('express')

// Include Handlebars module
const exphbs = require('express-handlebars')

// Include Flash and Session module
const flash = require('express-flash')
const session = require('express-session')

// Include mongoose module in models folder
require('./src/models/index')


// Import connect-mongo
const MongoStore = require('connect-mongo')
const mongooseClient = require('./src/models')

// Set app up as an express app
const app = express()

// Set port number
const portNo = 3000

// Set up to handle POST requests
app.use(express.json()) // needed if POST data is in JSON format
app.use(express.urlencoded()) // only needed for URL-encoded input

// Define where static assets live
app.use(express.static('public'))

// Configure Handlebars
app.engine(
    'hbs',
    exphbs.engine({
        defaultlayout: 'main',
        partialsPath: 'views/partials',
        extname: 'hbs',
        helpers: {
            displayFeeling: function(feeling) {
                if (feeling == 's') {
                    return '<button type="button" class="feeling_btn_clicked">&#128549;</button>'
                } else if (feeling == 'n') {
                    return '<button type="button" class="feeling_btn_clicked">&#128528;</button>'
                } else {
                    return '<button type="button" class="feeling_btn_clicked">&#128515;</button>'
                }
            },
            displayFeeling_clinician: function (feeling) {
                if (feeling == 's') {
                    return '&#128549;'
                } else if (feeling == 'n') {
                    return '&#128528;'
                } else {
                    return '&#128515;'
                }
            },
            //Highlight data when out of scope, "missing", "not required"
            showData: function(healthdata, max, min, flag) {
                if (!flag) {
                    return '<font color="brown">Not Required</font>'
                } else if (healthdata == 0) {
                    return '<font color="blue">Has Not Been Inserted</font>'
                } else if (healthdata > max || healthdata < min) {
                    return '<font color="red">' + healthdata + '</font>'
                } else {
                    return '<font color="black">' + healthdata + '</font>'
                }
            },
            patientHistoryData: function (healthdata, requireFlag) {
                if (!requireFlag) {
                    return '<font color="brown">Not Required</font>'
                } else if (requireFlag && healthdata == 0) {
                    return '<font color="blue">Has Not Been Inserted</font>'
                } else {
                    return '<font color="black">' + healthdata + '</font>'
                }
            },
            patientHistoryComment: function (feeling, comment) {
                if (comment !== undefined && comment != "") {
                    if (feeling == 's') {
                        return '<br />&#128549; : ' + comment
                    } else if (feeling == 'n') {
                        return '<br/>&#128528; : ' + comment
                    } else {
                        return '<br/>&#128515; : ' + comment
                    }
                } else {
                    return '<br/>'
                }
            },
            //Show the latest three lines of data on home page
            eachFive: function(context, options) {
                var ret = ''
                if (context.length < 5) {
                    for (var i = 0, j = context.length; i < j; i++) {
                        ret = ret + options.fn(context[i])
                    }
                    return ret
                }
                for (var i = 0, j = 5; i < j; i++) {
                    ret = ret + options.fn(context[i])
                }
                return ret
            },
        },
    })
)

// Set Handlebars view engine
app.set('view engine', 'hbs')

// Set path for views folder
const path = require('path')
app.set('views', path.join(__dirname, './src/views'))

// Flash messages for failed logins, and (possibly) other success/error messages
app.use(flash())

// Track authenticated users through login sessions
app.use(
    session({
        // The secret used to sign session cookies
        secret: process.env.SESSION_SECRET || 'keyboard cat',
        name: 'diabetesAtHome', // The cookie name
        saveUninitialized: false,
        resave: false,
        cookie: {
            sameSite: 'strict',
            httpOnly: true,
            secure: app.get('env') === 'production',
            maxAge: 1800000, // Sessions expire after 30 minutes
        },
        store: MongoStore.create({ clientPromise: mongooseClient }),
    })
)

if (app.get('env') === 'production') {
    app.set('trust proxy', 1) // Trust first proxy
}

// Initialise Passport.js
const passport = require('./passport')
app.use(passport.authenticate('session'))

// Load authentication router
const authRouter = require('./src/routes/auth')
app.use(authRouter)

// ==================== Routing ====================
app.get('/logout', function(req, res) {
    res.render('logout.hbs')
})

app.get('/diabetes', function(req, res) {
    const loggedIn = req.session.loggedIn
    res.render('diabetes.hbs', { loggedIn: loggedIn })
})

app.get('/website', function(req, res) {
    const loggedIn = req.session.loggedIn
    res.render('website.hbs', { loggedIn: loggedIn })
})

// If user attempts to access any other route, send a 404 error with a customized page
app.get('*', (req, res) => {
    res.render('404.hbs')
})

// Middleware to log a message each time a request arrives at the server.
app.use((req, res, next) => {
    console.log('message arrived: ' + req.method + ' ' + req.path)
    next()
})

// Tells the app to listen on portNo and logs that information to the console.
app.listen(process.env.PORT || portNo, () => {
    console.log('The library app is running!')
})
