const passport = require('passport')
const LocalStrategy = require('passport-local').Strategy
const User = require('./src/models/user')

// Serialize information to be stored in session/cookie
passport.serializeUser((user, done) => {
    done(undefined, user._id)
})

// When a request comes in, deserialize/expand the serialized information
// back to what it was (expand from id to full user)
passport.deserializeUser((userId, done) => {
    User.findById(userId, { password: 0 }, (err, user) => {
        if (err) {
            return done(err, undefined)
        }
        return done(undefined, user)
    })
})

// Define local authentication strategy for Passport
// http://www.passportjs.org/docs/downloads/html/#strategies
passport.use(
    new LocalStrategy((username, password, done) => {
        // Check if user exists and password matches the hash in the database
        User.findOne({ username }, {}, {}, (err, user) => {
            if (err) {
                return done(undefined, false, {
                    message: 'Unknown error has occurred',
                })
            }

            if (!user) {
                return done(undefined, false, {
                    message: 'Incorrect username or password',
                })
            }

            // Check password
            user.verifyPassword(password, (err, valid) => {
                if (err) {
                    return done(undefined, false, {
                        message: 'Unknown error has occurred',
                    })
                }

                if (!valid) {
                    return done(undefined, false, {
                        message: 'Incorrect username or password',
                    })
                }

                // If user exists and password matches the hash in the database
                return done(undefined, user)
            })
        })
    })
)

// Dummy insert users in DB
// Reference: https://www.mongodb.com/community/forums/t/collection-insertone-objectid-reference-issue/109665/2
/*
User.find({}, (err, users) => {
    if (users.length > 0) return
    User.create(
        {
            username: 'chris.blake@diabetesAthome.com',
            password: 'chrisb987654',
            secret: 'Diabetes@Home',
            role: 'clinician',
            patient_id: null,
            clinician_id: new BSON.ObjectId('62542d5ac3d4556125e7d4d0'),
        },
        { 
            username: 'aliciaK@email.com',
            password: 'ack12345',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6251a31f8dde0c85b5e3188f'),
            clinician_id: null,
        },
        { 
            username: 'henryc@email.com',
            password: 'hrc12345',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6251a90e8dde0c85b5e31890'),
            clinician_id: null,
        },
        { 
            username: 'patp@email.com',
            password: 'patp12345',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6254282dc3d4556125e7d4cd'),
            clinician_id: null,
        },
        { 
            username: 'brainc@email.com',
            password: 'biggerbrain1900',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6280d334f071cf8890b432b5'),
            clinician_id: null,
        },
        { 
            username: 'meganb@email.com',
            password: 'mememe2003',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6280d401d28855a04b2778c2'),
            clinician_id: null,
        },
        { 
            username: 'klara.stark@diabetesAthome.com',
            password: 'klaras987654',
            secret: 'Diabetes@Home',
            role: 'clinician',
            patient_id: new BSON.ObjectId('6280fabceafc0b3b2ef8dcc8'),
            clinician_id: null,
        },
        { 
            username: 'javanmel@email.com',
            password: 'jupiter1990',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6280fe2f6140d8e481ee96bd'),
            clinician_id: null,
        },
        { 
            username: 'allisonh@email.com',
            password: 'ally2001',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6280fd046140d8e481ee968a'),
            clinician_id: null,
        },
        { 
            username: 'romioherz@email.com',
            password: 'myjuliet1985',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6280fd966140d8e481ee969b'),
            clinician_id: null,
        },
        { 
            username: 'kelanb@email.com',
            password: 'keepgoing1983',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6280fde86140d8e481ee96ac'),
            clinician_id: null,
        },
        { 
            username: 'silafaul@email.com',
            password: 'imnotsilly1999',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6280fe596140d8e481ee96cc'),
            clinician_id: null,
        },
        { 
            username: 'mitzij@email.com',
            password: 'miz12345',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6284a79d314bfd7ef726c541'),
            clinician_id: null,
        },
        { 
            username: 'matd@email.com',
            password: 'matt1988',
            secret: 'Diabetes@Home',
            role: 'patient',
            patient_id: new BSON.ObjectId('6285a0770128715635dff3b2'),
            clinician_id: null,
        },
        (err) => {
            if (err) {
                console.log(err)
                return
            }
            console.log('Dummy user inserted')
        }
    )
})
*/

module.exports = passport
