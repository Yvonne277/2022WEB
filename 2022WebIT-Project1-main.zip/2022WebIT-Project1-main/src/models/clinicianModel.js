const mongoose = require('mongoose')

const clinicianNoteSchema = new mongoose.Schema({
    enter_date_time: { type: Date, default: Date.now },
    note: String,
})

const healthDataThresholdSchema = new mongoose.Schema({
    start_date: { type: Date, default: Date.now },
    end_date: { type: Date, default: null },
    blood_glucose_flag: { type: Boolean, default: false },
    blood_glucose_min: { type: Number, default: 0 },
    blood_glucose_max: { type: Number, default: 0 },
    weight_flag: { type: Boolean, default: false },
    weight_min: { type: Number, default: 0 },
    weight_max: { type: Number, default: 0 },
    dose_insulin_flag: { type: Boolean, default: false },
    dose_insulin_min: { type: Number, default: 0 },
    dose_insulin_max: { type: Number, default: 0 },
    exercise_flag: { type: Boolean, default: false },
    exercise_min: { type: Number, default: 0 },
    exercise_max: { type: Number, default: 0 },
})

const patientListSchema = new mongoose.Schema({
    patient_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient' },
    support_msg: String,
    clinician_note: [clinicianNoteSchema],
    health_data_threshold: [healthDataThresholdSchema],
})

const clinicianSchema = new mongoose.Schema({
    given_name: { type: String, required: true },
    family_name: String,
    email: String,
    patient_list: [patientListSchema],
})

const Clinician = mongoose.model('Clinician', clinicianSchema)
const HealthDataThreshold = mongoose.model('HealthDataThreshold',healthDataThresholdSchema)
const ClinicianNote = mongoose.model('ClinicianNote', clinicianNoteSchema)
const PatientList = mongoose.model('PatientList', patientListSchema)
module.exports = { Clinician, HealthDataThreshold, ClinicianNote, PatientList }