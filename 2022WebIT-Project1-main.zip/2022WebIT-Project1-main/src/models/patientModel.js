const mongoose = require('mongoose')

const healthDataSchema = new mongoose.Schema({
    enter_date: { type: Date, default: Date.now },
    blood_glucose_amount: { type: Number, default: 0 },
    blood_glucose_feeling: { type: String, default: '' },
    blood_glucose_comment: { type: String, default: '' },
    blood_glucose_input_time: { type: Date },
    weight_amount: { type: Number, default: 0 },
    weight_feeling: { type: String, default: '' },
    weight_comment: { type: String, default: '' },
    weight_input_time: { type: Date },
    dose_insulin_amount: { type: Number, default: 0 },
    dose_insulin_feeling: { type: String, default: '' },
    dose_insulin_comment: { type: String, default: '' },
    dose_insulin_input_time: { type: Date },
    exercise_amount: { type: Number, default: 0 },
    exercise_feeling: { type: String, default: '' },
    exercise_comment: { type: String, default: '' },
    exercise_input_time: { type: Date },
})

const patientSchema = new mongoose.Schema({
    given_name: { type: String, required: true },
    family_name: String,
    year_birth: { type: Number, min: 1900 },
    email: { type: String, unique: true },
    screen_name: { type: String, unique: true },
    brief_bio: String,
    health_data: [healthDataSchema],
})

const Patient = mongoose.model('Patient', patientSchema)
const HealthData = mongoose.model('HealthData', healthDataSchema)

module.exports = { Patient, HealthData }
