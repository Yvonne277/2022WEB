// Link to model
const { Patient } = require('../models/patientModel')
const { HealthDataThreshold } = require('../models/clinicianModel')
const { ClinicianNote } = require('../models/clinicianModel')
const { Clinician } = require('../models/clinicianModel')
const fileNotFoundStatus = 404

// Test getting today patient's health data from clinician id
const getTodayPatientHealthDataFromClinicianId = async (req, res, next) => {
    try {
        // Check valid logged in clinician
        if (req.user && req.user.clinician_id != '') {
        const loggedIn = req.session.loggedIn
        const clinicianID = req.user.clinician_id
        const clinician = await Clinician.findById(clinicianID).lean()

        if (!clinician) {
            // No clinician found in database
            res.render(fileNotFoundStatus)
            console.log('Not found clinician')
            return
        }
        // Found clinician
        // List all patients related to that clinician and the latest health data thresholds
        const patientList = await Clinician.aggregate([
            { $unwind: '$patient_list' },
            { $match: { '_id': clinicianID } },
            {
                $group: {
                    _id: '$patient_list.patient_id',
                    health_data_threshold: {
                        $last: '$patient_list.health_data_threshold',
                    },
                },
            },
            {
                $project: {
                    _id: 0,
                    patient_id: '$_id',
                    health_data_threshold: '$health_data_threshold',
                },
            },
        ])

        // Loop through each patient id to get the current health data record
        // Reference: https://advancedweb.hu/how-to-use-async-functions-with-array-foreach-in-javascript/
        let currentPatientRecords = []
        let recentPatientComments = []
        let certainClinician = []
        certainClinician.push({ clinician_name: clinician.given_name })
        await patientList.reduce(async (memo, patient) => {
            await memo

            const specificPatient = await Patient.findById(
                patient.patient_id
            ).lean()

            if (!specificPatient) {
                // No specific patient found in database
                res.render(fileNotFoundStatus)
                return
            }
            // Found specific patient
            // get the current health data record of that specific patient
            const currentDate = new Date()
            const melbCurrentDateStr = currentDate.toLocaleDateString('en-AU', {
                timeZone: 'Australia/Melbourne',
                dateStyle: 'short',
            })

            specificPatient.health_data.forEach(function (healthData) {
                const enterDate = healthData.enter_date
                const enterDateStr = enterDate.toLocaleDateString('en-AU', {
                    timeZone: 'Australia/Melbourne',
                    dateStyle: 'short',
                })

                if (enterDateStr === melbCurrentDateStr) {
                    const specificPatientHealthDataThreshold =
                        patient.health_data_threshold
                    specificPatientHealthDataThreshold.forEach(function (
                        thresholds
                    ) {
                        const endDate = thresholds.end_date

                        if (!endDate) {
                            currentPatientRecords.push({
                                patientId: specificPatient._id,
                                patientName:
                                    specificPatient.given_name +
                                    ' ' +
                                    specificPatient.family_name,
                                currentHealthRecord: {
                                    enter_date: enterDateStr,
                                    healthData,
                                    blood_glucose_flag:
                                        thresholds.blood_glucose_flag,
                                    blood_glucose_min:
                                        thresholds.blood_glucose_min,
                                    blood_glucose_max:
                                        thresholds.blood_glucose_max,
                                    weight_flag: thresholds.weight_flag,
                                    weight_min: thresholds.weight_min,
                                    weight_max: thresholds.weight_max,
                                    dose_insulin_flag:
                                        thresholds.dose_insulin_flag,
                                    dose_insulin_min:
                                        thresholds.dose_insulin_min,
                                    dose_insulin_max:
                                        thresholds.dose_insulin_max,
                                    exercise_flag: thresholds.exercise_flag,
                                    exercise_min: thresholds.exercise_min,
                                    exercise_max: thresholds.exercise_max,
                                    max: Math.max(
                                        healthData.blood_glucose_input_time,
                                        healthData.weight_input_time,
                                        healthData.dose_insulin_input_time,
                                        healthData.exercise_input_time
                                    ),
                                },
                            })
                        }
                    })
                }
                // comment function part
                if (healthData.blood_glucose_feeling != '') {
                    recentPatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.blood_glucose_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.blood_glucose_feeling,
                        comment: healthData.blood_glucose_comment,
                        type: 'blood_glucose',
                    })
                }
                if (healthData.weight_feeling != '') {
                    recentPatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.weight_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.weight_feeling,
                        comment: healthData.weight_comment,
                        type: 'weight',
                    })
                }
                if (healthData.dose_insulin_feeling != '') {
                    recentPatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.dose_insulin_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.dose_insulin_feeling,
                        comment: healthData.dose_insulin_comment,
                        type: 'dose_insulin',
                    })
                }
                if (healthData.exercise_feeling != '') {
                    recentPatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.exercise_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.exercise_feeling,
                        comment: healthData.exercise_comment,
                        type: 'exercise',
                    })
                }
            })
        }, undefined)

        // Sort the recent patient comments by input time
        recentPatientComments.sort(function (x, y) {
            return y.input_time - x.input_time
        })

        // Sort the patient data by recent enter data Time
        currentPatientRecords.sort(function (x, y) {
            return y.max - x.max
        })

        // change input_time to normal date & time format
        recentPatientComments.forEach(function (comment) {
            if (comment.input_time) {
                comment.input_time = comment.input_time.toLocaleString(
                    'en-AU',
                    { timeZone: 'Australia/Melbourne' }
                )
            }
        })

        // Render the page
        return res.render('dashboard.hbs', {
            certainClinician: certainClinician,
            currentPatientRecords: currentPatientRecords,
            recentPatientComments: recentPatientComments,
            loggedIn: loggedIn,
        })
        } else {
            // Invalid clinician's login data, send user back to login page
            res.redirect('/')
            return
        }
    } catch (err) {
        return next(err)
    }
}

// get the patient basic info from certain clinian id
const getPatientGeneralInfoFromClinicianId = async (req, res, next) => {
    try {
        // Check valid logged in clinician
        if (req.user && req.user.clinician_id != '') {
            const patient = await Patient.findById(
                req.params.patient_id
            ).lean()
            // Search for clinician related to the found patient
            const clinician = await Clinician.findOne({ patient_id: patient._id })
            // Search for the certain patient's health data
            const dataFromClinician = await Clinician.aggregate([
                { $unwind: '$patient_list' },
                { $match: { 'patient_list.patient_id': patient._id } },
                {
                    $project: {
                        _id: '$patient_list._id',
                        support_msg: '$patient_list.support_msg',
                        clinician_note
                        : '$patient_list.clinician_note',
                        health_data_threshold:
                            '$patient_list.health_data_threshold',
                    },
                },
            ])
            let generalInfo = []
            let allData = []
            let PatientComments = []
            const patientHealthData = patient.health_data
            patientHealthData.forEach(function (healthData) {
                // comment function part
                if (healthData.blood_glucose_feeling != '') {
                    PatientComments.push({
                        patientId: patient._id,
                        input_time: healthData.blood_glucose_input_time.toLocaleString(
                            'en-AU',
                            { timeZone: 'Australia/Melbourne' }
                        ),
                        patientName:
                        patient.given_name +
                            ' ' +
                        patient.family_name,
                        feeling: healthData.blood_glucose_feeling,
                        comment: healthData.blood_glucose_comment,
                        type: 'blood_glucose',
                    })
                }
                if (healthData.weight_feeling != '') {
                    PatientComments.push({
                        patientId: patient._id,
                        input_time: healthData.weight_input_time.toLocaleString(
                            'en-AU',
                            { timeZone: 'Australia/Melbourne' }
                        ),
                        patientName:
                        patient.given_name +
                            ' ' +
                        patient.family_name,
                        feeling: healthData.weight_feeling,
                        comment: healthData.weight_comment,
                        type: 'weight',
                    })
                }
                if (healthData.dose_insulin_feeling != '') {
                    PatientComments.push({
                        patientId: patient._id,
                        input_time: healthData.dose_insulin_input_time.toLocaleString(
                            'en-AU',
                            { timeZone: 'Australia/Melbourne' }
                        ),
                        patientName:
                        patient.given_name +
                            ' ' +
                            patient.family_name,
                        feeling: healthData.dose_insulin_feeling,
                        comment: healthData.dose_insulin_comment,
                        type: 'dose_insulin',
                    })
                }
                if (healthData.exercise_feeling != '') {
                    PatientComments.push({
                        patientId: patient._id,
                        input_time: healthData.exercise_input_time.toLocaleString(
                            'en-AU',
                            { timeZone: 'Australia/Melbourne' }
                        ),
                        patientName:
                        patient.given_name +
                            ' ' +
                            patient.family_name,
                        feeling: healthData.exercise_feeling,
                        comment: healthData.exercise_comment,
                        type: 'exercise',
                    })
                }
                const enterDate = healthData.enter_date
                const specificPatientHealthDataThreshold = dataFromClinician[0].health_data_threshold
                thresholdLength = specificPatientHealthDataThreshold.length
                specificPatientHealthDataThreshold.every(function (thresholds) {
                    const startDateStr = thresholds.start_date
                    const endDateStr = thresholds.end_date
                    if (enterDate >= startDateStr && enterDate <= endDateStr) {
                        const enterDateStr = enterDate.toLocaleDateString('en-AU', {
                            timeZone: 'Australia/Melbourne',
                            dateStyle: 'short',
                        })
                        allData.push({
                            patient_id: patient._id,
                            patient_name: patient.given_name + ' ' + patient.family_name,
                            HealthRecord:{ 
                                enter_date: enterDateStr,
                                blood_glucose_amount: healthData.blood_glucose_amount,
                                blood_glucose_flag: thresholds.blood_glucose_flag,
                                blood_glucose_min: thresholds.blood_glucose_min,
                                blood_glucose_max: thresholds.blood_glucose_max,
                                weight_amount: healthData.weight_amount,
                                weight_flag: thresholds.weight_flag,
                                weight_min: thresholds.weight_min,
                                weight_max: thresholds.weight_max,
                                dose_insulin_amount: healthData.dose_insulin_amount,
                                dose_insulin_flag: thresholds.dose_insulin_flag,
                                dose_insulin_min: thresholds.dose_insulin_min,
                                dose_insulin_max: thresholds.dose_insulin_max,
                                exercise_amount: healthData.exercise_amount,
                                exercise_flag: thresholds.exercise_flag,
                                exercise_min: thresholds.exercise_min,
                                exercise_max: thresholds.exercise_max,
                                max: Math.max(
                                    healthData.blood_glucose_input_time,
                                    healthData.weight_input_time,
                                    healthData.dose_insulin_input_time,
                                    healthData.exercise_input_time
                                ),
                            }
                        })
                        return false;
                    }
                    thresholdLength -= 1
                    if (thresholdLength == 1 || specificPatientHealthDataThreshold.length == 1) {
                        const enterDateStr = enterDate.toLocaleDateString('en-AU', {
                            timeZone: 'Australia/Melbourne',
                            dateStyle: 'short',
                        })
                        console.log('enterDateStr: ', enterDateStr)
                        allData.push({
                            patient_id: patient._id,
                            patient_name: patient.given_name + ' ' + patient.family_name,
                            HealthRecord:{ 
                                enter_date: enterDateStr,
                                blood_glucose_amount: healthData.blood_glucose_amount,
                                blood_glucose_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].blood_glucose_flag,
                                blood_glucose_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].blood_glucose_min,
                                blood_glucose_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].blood_glucose_max,
                                weight_amount: healthData.weight_amount,
                                weight_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].weight_flag,
                                weight_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].weight_min,
                                weight_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].weight_max,
                                dose_insulin_amount: healthData.dose_insulin_amount,
                                dose_insulin_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].dose_insulin_flag,
                                dose_insulin_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].dose_insulin_min,
                                dose_insulin_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].dose_insulin_max,
                                exercise_amount: healthData.exercise_amount,
                                exercise_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].exercise_flag,
                                exercise_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].exercise_min,
                                exercise_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].exercise_max,
                                max: Math.max(
                                    healthData.blood_glucose_input_time,
                                    healthData.weight_input_time,
                                    healthData.dose_insulin_input_time,
                                    healthData.exercise_input_time
                                ),
                            }
                        })
                    } return true;
                })
            })
            // get health data from patient
            // get latest threshold data
            const specificPatientHealthDataThreshold = dataFromClinician[0].health_data_threshold
            specificPatientHealthDataThreshold.forEach(function (thresholds) {
                const endDate = thresholds.end_date
                if (!endDate) {
                    generalInfo.push({
                        patient_id: patient._id,
                        givenName: patient.given_name,
                        familyName: patient.family_name,
                        yearBirth: patient.year_birth,
                        screenName: patient.screen_name,
                        briefBio: patient.brief_bio,
                        support_msg: dataFromClinician[0].support_msg,
                        patient_list_id: dataFromClinician[0]._id,
                        health_data_threshold_id : thresholds._id,
                        blood_glucose_flag : thresholds.blood_glucose_flag,
                        blood_glucose_min : thresholds.blood_glucose_min,
                        blood_glucose_max : thresholds.blood_glucose_max,
                        weight_flag : thresholds.weight_flag,
                        weight_min : thresholds.weight_min,
                        weight_max : thresholds.weight_max,
                        dose_insulin_flag : thresholds.dose_insulin_flag,
                        dose_insulin_min : thresholds.dose_insulin_min,
                        dose_insulin_max : thresholds.dose_insulin_max,
                        exercise_flag : thresholds.exercise_flag,
                        exercise_min : thresholds.exercise_min,
                        exercise_max : thresholds.exercise_max
                    })
                }
            })
            let clinicianNote = []
            noteDetails = dataFromClinician[0].clinician_note
            noteDetails.forEach(function (note) {
                clinicianNote.push({
                    enter_date_time: note.enter_date_time,
                    note: note.note,
                })
            })
            // Sort allData by enter_date
            allData.sort(function(a, b) {
                return b.HealthRecord.max - a.HealthRecord.max
            })
            // Sort the recent patient comments by input time
            clinicianNote.sort(function (x, y) {
                return y.enter_date_time - x.enter_date_time
            })
            // Sort the recent patient comments by input time
            PatientComments.sort(function (x, y) {
                return y.input_time - x.input_time
            })

            // change input_time to normal date & time format
            clinicianNote.forEach(function (note) {
                if (note.enter_date_time) {
                    note.enter_date_time = note.enter_date_time.toLocaleString(
                        'en-AU',
                        { timeZone: 'Australia/Melbourne' }
                    )
                }
            })
            
            return res.render('patientInfo.hbs', {
                generalInfo: generalInfo,
                allData: allData,
                clinicianNote: clinicianNote,
                PatientComments: PatientComments,
            })
        } else {
            // Invalid clinician's login data, send user back to login page
            res.redirect('/')
            return
        }
    } catch (err) {
        return next(err)
    }
}

// Add and edit the general info of a patient
const editGeneralInfo = async (req, res, next) => {
    try {
        // Check valid logged in clinician
        if (req.user && req.user.clinician_id != '') {
            console.log("Do editing the patient's general info")
            const patientID = req.params.patient_id

            // Find the specific patient data.
            let thisPatient = await Patient.findOne({ _id: req.params.patient_id })
            // Search for clinician related to the found patient
            const clinician = await Clinician.findOne({ "patient_list.patient_id": thisPatient._id })

            // General info
            let patient_list_id = req.body.patient_list_id
            let given_name = req.body.given_name
            let family_name = req.body.family_name
            let year_birth = req.body.year_birth
            let screen_name = req.body.screen_name
            let brief_bio = req.body.brief_bio

            // Threshold data
            let health_data_threshold_id = req.body.health_data_threshold_id
            let blood_glucose_flag = req.body.blood_glucose_flag
            let blood_glucose_min = req.body.blood_glucose_min
            let blood_glucose_max = req.body.blood_glucose_max
            let weight_flag = req.body.weight_flag
            let weight_min = req.body.weight_min
            let weight_max = req.body.weight_max
            let dose_insulin_flag = req.body.dose_insulin_flag
            let dose_insulin_min = req.body.dose_insulin_min
            let dose_insulin_max = req.body.dose_insulin_max
            let exercise_flag = req.body.exercise_flag
            let exercise_min = req.body.exercise_min
            let exercise_max = req.body.exercise_max

            // Support message
            let support_msg = req.body.support_msg

            // Clinician note
            let clinician_note = req.body.clinicianNote
            
            // Update general info of patient
            if (given_name !== undefined) {
                // Valid general info is submiited
                console.log("Update general info of patient")
                const duplicateScreenName = await Patient.findOne({ "screen_name": screen_name })
                if((duplicateScreenName != null) && (screen_name != thisPatient.screen_name))  {
                    // Error duplicated screen name found
                    console.log("Error duplicated screen name found")
                    req.flash('messages', {
                        error: 'Screen name already existed.',
                    })
                    return res.redirect('/clinician/dashboard/' + patientID) // Redirect user back to general info page and Show error message on the screen
                } else if( screen_name != thisPatient.screen_name ){
                    // No duplicated screen name
                    console.log("No duplicated screen name")
                    await Patient.findOneAndUpdate(
                    { _id: thisPatient._id },
                    {
                        $set: {
                            'given_name': given_name,
                            'family_name': family_name,
                            'year_birth': year_birth,
                            'screen_name': screen_name,
                            'brief_bio': brief_bio,
                        },
                    },
                    { new: true }
                )} else {
                    // No duplicated screen name
                    console.log("No duplicated screen name")
                    await Patient.findOneAndUpdate(
                    { _id: thisPatient._id },
                    {
                        $set: {
                            'given_name': given_name,
                            'family_name': family_name,
                            'year_birth': year_birth,
                            'screen_name': screen_name,
                            'brief_bio': brief_bio,
                        },
                    },
                    { new: true }
                )}
            }
            
            // Update support message
            if (support_msg !== undefined) {
                // Valid support message is submiited
                console.log("Update support message")
                await Clinician.findOneAndUpdate(
                { _id: clinician._id },
                {
                    $set: {
                        'patient_list.$[el].support_msg': support_msg,
                    },
                },
                { 
                    arrayFilters: [{ 'el._id': patient_list_id }],
                    new: true 
                })
            }

            // Update and Insert threshold data
            if (typeof health_data_threshold_id !== 'undefined' && health_data_threshold_id) {
                // Valid threshold is submiited
                console.log("Update threshold data")

                // Current used data threshold, Update end date to be current date
                await Clinician.findOneAndUpdate(
                    { "_id": clinician._id },
                    {
                        $set: {
                            'patient_list.$[patientListFilter].health_data_threshold.$[thresholdFilter].end_date': new Date(),
                        },
                    },
                    {
                        arrayFilters: [
                            {'patientListFilter._id': patient_list_id }, 
                            {'thresholdFilter._id': health_data_threshold_id}
                        ],
                        multi: true 
                    }
                )

                console.log('blood_glucose_flag = ' + blood_glucose_flag)
                console.log('blood_glucose_min = ' + blood_glucose_min)
                console.log('blood_glucose_max = ' + blood_glucose_max)
                console.log('dose_insulin_flag = ' + dose_insulin_flag)
                console.log('dose_insulin_min = ' + dose_insulin_min)
                console.log('dose_insulin_max = ' + dose_insulin_max)

                // Create threshold object
                const newPatientThreshold = new HealthDataThreshold({
                    start_date: new Date(),
                    end_date: null,
                    blood_glucose_flag: blood_glucose_flag,
                    blood_glucose_min: blood_glucose_min,
                    blood_glucose_max: blood_glucose_max,
                    weight_flag: weight_flag,
                    weight_min: weight_min,
                    weight_max: weight_max,
                    dose_insulin_flag: dose_insulin_flag,
                    dose_insulin_min: dose_insulin_min,
                    dose_insulin_max: dose_insulin_max,
                    exercise_flag: exercise_flag,
                    exercise_min: exercise_min,
                    exercise_max: exercise_max,
                })

                // Insert new threshold object
                Clinician.update(
                    {_id: clinician._id, 'patient_list._id': patient_list_id},
                    {$push: 
                        {"patient_list.$.health_data_threshold": newPatientThreshold}
                    },
                    {upsert: true}, function (err, docs) {
                        if (err) {
                            console.log('Error on updating threshold data')
                            req.flash('messages', {
                                error: 'Error occur while updating threshold data, please try again later',
                            })
                            return res.redirect('/clinician/dashboard/' + patientID)
                        }
                        console.log('docs threshold = ' + docs)
                    }
                )
            }

            // Insert Clinician Note
            //let clinician_note = req.body.clinician_note
            if (clinician_note && typeof clinician_note !== 'undefined' && clinician_note != "") {
                // Valid threshold is submiited
                console.log("Insert clinician note")

                // Create clinician note object
                const newClinicianNote = ClinicianNote({
                    enter_date_time: new Date(),
                    note: clinician_note,
                })

                // Insert new threshold object
                Clinician.update(
                    {_id: clinician._id, 'patient_list._id': patient_list_id},
                    {$push: 
                        {"patient_list.$.clinician_note": newClinicianNote}
                    },
                    {upsert: true}, function (err, docs) {
                        if (err) {
                            console.log('Error on updating clinician note')
                            req.flash('messages', {
                                error: 'Error occur while updating clinician note, please try again later',
                            })
                            return res.redirect('/clinician/dashboard/' + patientID)
                        }
                        console.log('docs clinician note = ' + docs)
                    }
                )
            }
    
            req.flash('messages', {
                success: 'Update information successfully',
            })

             // Refresh the page to see the recorded data
            return res.redirect('/clinician/dashboard/' + patientID)
        } else {
            // Invalid clinician's login data, send user back to login page
            res.redirect('/')
            return
        }
    } catch (err) {
        return next(err)
    }
}

// getting all patients' health data from clinician id accendingly with date
const getPatientHealthDataFromClinicianId = async (req, res, next) => {
    try {
        if (req.user && req.user.clinician_id != '') {
            const loggedIn = req.session.loggedIn
            const clinicianID = req.user.clinician_id
            const clinician = await Clinician.findById(clinicianID).lean()

        if (!clinician) {
            // No clinician found in database
            res.render(fileNotFoundStatus)
            console.log('Not found clinician')
            return
        }
        // Found clinician
        let certainClinician = []
        certainClinician.push({ clinician_name: clinician.given_name })
        // List all patients related to that clinician and all health data thresholds
        const patientList = await Clinician.aggregate([
            { $unwind: '$patient_list' },
            { $match: { '_id': clinicianID } },
            {
                $group: {
                    _id: '$patient_list.patient_id',
                    health_data_threshold: {
                        $push: '$patient_list.health_data_threshold',
                    },
                },
            },
            {
                $project: {
                    _id: 0,
                    patient_id: '$_id',
                    health_data_threshold: '$health_data_threshold',
                },
            },
        ])
        // Loop through each patient id to get the all health data record
        let patientHealthData = []
        await patientList.reduce(async (memo, patient) => {
            await memo

            const specificPatient = await Patient.findById(
                patient.patient_id
            ).lean()

            if (!specificPatient) {
                // No specific patient found in database
                res.render(fileNotFoundStatus)
                return
            }
            // Found specific patient
            // get the all health data record of that specific patient
            specificPatient.health_data.forEach(function (healthData) {
                const enterDate = healthData.enter_date
                const specificPatientHealthDataThreshold = patient.health_data_threshold[0]
                thresholdLength = specificPatientHealthDataThreshold.length
                specificPatientHealthDataThreshold.every(function (thresholds) {
                    const startDateStr = thresholds.start_date
                    const endDateStr = thresholds.end_date
                    if (enterDate >= startDateStr && enterDate <= endDateStr) {
                        const enterDateStr = enterDate.toLocaleDateString('en-AU', {
                            timeZone: 'Australia/Melbourne',
                            dateStyle: 'short',
                        })
                        patientHealthData.push({
                            patient_id: specificPatient._id,
                            patient_name: specificPatient.given_name + ' ' + specificPatient.family_name,
                            HealthRecord:{ 
                                enter_date: enterDateStr,
                                blood_glucose_amount: healthData.blood_glucose_amount,
                                blood_glucose_flag: thresholds.blood_glucose_flag,
                                blood_glucose_min: thresholds.blood_glucose_min,
                                blood_glucose_max: thresholds.blood_glucose_max,
                                weight_amount: healthData.weight_amount,
                                weight_flag: thresholds.weight_flag,
                                weight_min: thresholds.weight_min,
                                weight_max: thresholds.weight_max,
                                dose_insulin_amount: healthData.dose_insulin_amount,
                                dose_insulin_flag: thresholds.dose_insulin_flag,
                                dose_insulin_min: thresholds.dose_insulin_min,
                                dose_insulin_max: thresholds.dose_insulin_max,
                                exercise_amount: healthData.exercise_amount,
                                exercise_flag: thresholds.exercise_flag,
                                exercise_min: thresholds.exercise_min,
                                exercise_max: thresholds.exercise_max,
                                max: Math.max(
                                    healthData.blood_glucose_input_time,
                                    healthData.weight_input_time,
                                    healthData.dose_insulin_input_time,
                                    healthData.exercise_input_time
                                ),
                            }
                        })
                        return false;
                    }
                    thresholdLength -= 1
                    if (thresholdLength == 1 || specificPatientHealthDataThreshold.length == 1) {
                        const enterDateStr = enterDate.toLocaleDateString('en-AU', {
                            timeZone: 'Australia/Melbourne',
                            dateStyle: 'short',
                        })
                        patientHealthData.push({
                            patient_id: specificPatient._id,
                            patient_name: specificPatient.given_name + ' ' + specificPatient.family_name,
                            HealthRecord:{ 
                                enter_date: enterDateStr,
                                blood_glucose_amount: healthData.blood_glucose_amount,
                                blood_glucose_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].blood_glucose_flag,
                                blood_glucose_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].blood_glucose_min,
                                blood_glucose_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].blood_glucose_max,
                                weight_amount: healthData.weight_amount,
                                weight_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].weight_flag,
                                weight_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].weight_min,
                                weight_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].weight_max,
                                dose_insulin_amount: healthData.dose_insulin_amount,
                                dose_insulin_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].dose_insulin_flag,
                                dose_insulin_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].dose_insulin_min,
                                dose_insulin_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].dose_insulin_max,
                                exercise_amount: healthData.exercise_amount,
                                exercise_flag: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].exercise_flag,
                                exercise_min: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].exercise_min,
                                exercise_max: specificPatientHealthDataThreshold[(specificPatientHealthDataThreshold.length)-1].exercise_max,
                                max: Math.max(
                                    healthData.blood_glucose_input_time,
                                    healthData.weight_input_time,
                                    healthData.dose_insulin_input_time,
                                    healthData.exercise_input_time
                                ),
                            }
                        })
                    } return true;
                })
            })
        }, undefined)

        // Sort the patient health data by max input time
        patientHealthData.sort(function (a, b) {
            return b.HealthRecord.max - a.HealthRecord.max
        })

        // Sort the patient data by date
        patientHealthData.sort(function (x, y) {
            return y.HealthRecord.enter_date - x.HealthRecord.enter_date
        })

        // Render the page
        return res.render('allData.hbs', {
            certainClinician: certainClinician,
            patientHealthData: patientHealthData,
            loggedIn: loggedIn,
        })
        } else {
            // Invalid clinician's login data, send user back to login page
            res.redirect('/')
            return
        }
    } catch (err) {
        return next(err)
    }
}

// Get all comments of all patient from a certain clinician_id
const getPatientCommentsFromClinicianId = async (req, res, next) => {
    try {
        // Check valid logged in clinician
        if (req.user && req.user.clinician_id != '') {
            const loggedIn = req.session.loggedIn
            const clinicianID = req.user.clinician_id
            const clinician = await Clinician.findById(clinicianID).lean()

        if (!clinician) {
            // No clinician found in database
            res.render(fileNotFoundStatus)
            console.log('Not found clinician')
            return
        }
        // Found clinician
        // List all patients related to that clinician and the latest health data thresholds
        const patientList = await Clinician.aggregate([
            { $unwind: '$patient_list' },
            {
                $group: {
                    _id: '$patient_list.patient_id',
                    health_data_threshold: {
                        $last: '$patient_list.health_data_threshold',
                    },
                },
            },
            {
                $project: {
                    _id: 0,
                    patient_id: '$_id',
                    health_data_threshold: '$health_data_threshold',
                },
            },
        ])

        // Loop through each patient id to get the current health data record
        // Reference: https://advancedweb.hu/how-to-use-async-functions-with-array-foreach-in-javascript/
        let PatientComments = []
        await patientList.reduce(async (memo, patient) => {
            await memo

            const specificPatient = await Patient.findById(
                patient.patient_id
            ).lean()

            if (!specificPatient) {
                // No specific patient found in database
                res.render(fileNotFoundStatus)
                return
            }
            // Found specific patient
            // get the current health data record of that specific patient
            specificPatient.health_data.forEach(function (healthData) {
                // comment function part
                if (healthData.blood_glucose_feeling != '') {
                    PatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.blood_glucose_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.blood_glucose_feeling,
                        comment: healthData.blood_glucose_comment,
                        type: 'blood_glucose',
                    })
                }
                if (healthData.weight_feeling != '') {
                    PatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.weight_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.weight_feeling,
                        comment: healthData.weight_comment,
                        type: 'weight',
                    })
                }
                if (healthData.dose_insulin_feeling != '') {
                    PatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.dose_insulin_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.dose_insulin_feeling,
                        comment: healthData.dose_insulin_comment,
                        type: 'dose_insulin',
                    })
                }
                if (healthData.exercise_feeling != '') {
                    PatientComments.push({
                        patientId: specificPatient._id,
                        input_time: healthData.exercise_input_time,
                        patientName:
                            specificPatient.given_name +
                            ' ' +
                            specificPatient.family_name,
                        feeling: healthData.exercise_feeling,
                        comment: healthData.exercise_comment,
                        type: 'exercise',
                    })
                }
            })
        }, undefined)

        // Sort the recent patient comments by input time
        PatientComments.sort(function (x, y) {
            return y.input_time - x.input_time
        })

        // change input_time to normal date & time format
        PatientComments.forEach(function (comment) {
            if (comment.input_time) {
                comment.input_time = comment.input_time.toLocaleString(
                    'en-AU',
                    { timeZone: 'Australia/Melbourne' }
                )
            }
        })

        // Render the page
        return res.render('allcomment.hbs', {
            PatientComments: PatientComments,
        })
        } else {
            // Invalid clinician's login data, send user back to login page
            res.redirect('/')
            return
        }
    } catch (err) {
        return next(err)
    }
}

module.exports = {
    getTodayPatientHealthDataFromClinicianId,
    getPatientGeneralInfoFromClinicianId,
    editGeneralInfo,
    getPatientHealthDataFromClinicianId,
    getPatientCommentsFromClinicianId,
}
