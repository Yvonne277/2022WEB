// Link to model
const { Patient } = require('../models/patientModel')
const { HealthData } = require('../models/patientModel')
const { Clinician } = require('../models/clinicianModel')
const fileNotFoundStatus = 404

function formatDate(date) {
    var d = new Date(date),
        month = "" + (d.getMonth() + 1),
        day = "" + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;
    return [year, month, day].join("-");

}

function getDateList(timespan) {
    const oneDay = 86400000;
    const today = Date.now();
    const dateList = [];
    for (let i = 0; i < timespan; i++) {
        dateList.unshift(formatDate(today - i * oneDay));
    }
    return dateList;
}


function countRequiredInputDays(healthDataThreshold) {
    console.log('Do countRequiredInputDays')

    let countRequiredDays = 0
    if (healthDataThreshold) {
        healthDataThreshold.forEach(function(threshold) {
            const startDate = threshold.start_date
            let endDate = threshold.end_date

            if (!endDate) {
                endDate = new Date() // Set end date as current date for the current threshold data (end date is saved as null in DB)
            }

            const blood_glucose_flag = threshold.blood_glucose_flag
            const weight_flag = threshold.weight_flag
            const dose_insulin_flag = threshold.dose_insulin_flag
            const exercise_flag = threshold.exercise_flag

            if (
                blood_glucose_flag ||
                weight_flag ||
                dose_insulin_flag ||
                exercise_flag
            ) {
                // There is a data required in this date range so, calculate the number of days of this date range
                // Reference: https://linuxhint.com/calculate-days-between-two-dates-javascript/
                const timesDifference = endDate.getTime() - startDate.getTime()
                console.log('timesDifference = ' + timesDifference)
                let daysDifference = Math.round(
                    timesDifference / (1000 * 3600 * 24)
                )

                if (daysDifference <= 0) {
                    daysDifference = 1
                }

                console.log('daysDifference = ' + daysDifference)
                countRequiredDays += daysDifference
            }
        })
    }

    console.log('Total countRequiredInputDays = ' + countRequiredDays)
    return countRequiredDays
}

function countEngagementDays(patientHealthRecords) {
    console.log('Do countEngagementDays')

    let countInputDays = 0
    if (patientHealthRecords) {
        countInputDays = patientHealthRecords.length
    }

    console.log('Total countEngagementDays = ' + countInputDays)
    return countInputDays
}

async function calculatePatientEngagementRate(patientID) {
    let engagementRate = 0
        // Get patient id as input parameter and get patient info from DB
    const patient = await Patient.findById(patientID).lean()

    if (!patient) {
        // No patient found in database
        return engagementRate
    } else {
        // Found patient in DB
        const patientHealthRecords = patient.health_data // Find all health records of that patient id
        const daysEngagement = countEngagementDays(patientHealthRecords) // Calculate total engagement day of that patient

        // Search for clinician related to the found patient
        const clinician = await Clinician.findOne({
            patient_id: patient._id,
        })

        if (!clinician) {
            // No clinician found in database
            return engagementRate
        } else {
            // Found clinician in DB
            // Search for patient's data from the related clinician model
            const dataFromClinician = await Clinician.aggregate([
                { $unwind: '$patient_list' },
                { $match: { 'patient_list.patient_id': patient._id } },
                {
                    $project: {
                        _id: 0,
                        support_msg: '$patient_list.support_msg',
                        health_data_threshold: '$patient_list.health_data_threshold',
                    },
                },
            ])

            // Find all threshold data of that patient id
            const healthDataThreshold =
                dataFromClinician[0].health_data_threshold
            const daysRequiredInput =
                countRequiredInputDays(healthDataThreshold) // Calculate total required input days of that patient

            // Use 'daysEngagement' and 'daysRequiredInput' to calculate engagement rate of that patient
            engagementRate = (daysEngagement * 100) / daysRequiredInput

            console.log(
                'Result from engagementRate calculation = ' + engagementRate
            )

            // Return the calculated engagement rate
            return engagementRate
        }
    }
}

// Handle request to get patient data by a specific patient id
const getPatientDataById = async(req, res, next) => {
    try {
        // Check valid logged in patient
        if (req.user && req.user.patient_id != '') {
            const loggedIn = req.session.loggedIn
            const patientID = req.user.patient_id
            const patient = await Patient.findById(patientID).lean() // Get patient's information

            if (!patient) {
                // No patient found in database
                res.render(fileNotFoundStatus)
                return
            }
            // Found patient: Set the patientData object to prepare data for showing in the PatientUI
            let patientData = {}
            patientData['_id'] = patient._id
            patientData['given_name'] = patient.given_name
            patientData['family_name'] = patient.family_name
            patientData['year_birth'] = patient.year_birth
            patientData['email'] = patient.email
            patientData['screen_name'] = patient.screen_name
            patientData['brief_bio'] = patient.brief_bio

            // Find the patient's today health record in Patient model
            // Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/toLocaleString
            const currentDate = new Date()
            const melbCurrentDateStr = currentDate.toLocaleString('en-AU', {
                timeZone: 'Australia/Melbourne',
                dateStyle: 'short',
            })

            let countSavedData = 0
            let countRequiredData = 0
            const patientHealthRecords = patient.health_data
            patientHealthRecords.forEach(function(healthRecord) {
                const enterDate = healthRecord.enter_date
                const enterDateStr = enterDate.toLocaleString('en-AU', {
                    timeZone: 'Australia/Melbourne',
                    dateStyle: 'short',
                })

                if (enterDateStr && enterDateStr === melbCurrentDateStr) {
                    // Found the today health record
                    // Put today health data record into patientData object
                    patientData['health_record_id'] = healthRecord._id

                    patientData['enter_date'] = healthRecord.enter_date
                    patientData['format_date'] = formatDate(healthRecord.enter_date)

                    patientData['blood_glucose_amount'] =
                        healthRecord.blood_glucose_amount
                    patientData['blood_glucose_amount_saved'] =
                        healthRecord.blood_glucose_amount > 0
                    patientData['blood_glucose_feeling'] =
                        healthRecord.blood_glucose_feeling
                    patientData['blood_glucose_feeling_saved'] =
                        healthRecord.blood_glucose_feeling != ''
                    patientData['blood_glucose_comment'] =
                        healthRecord.blood_glucose_comment
                    patientData['blood_glucose_comment_saved'] =
                        healthRecord.blood_glucose_comment != ''

                    patientData['weight_amount'] = healthRecord.weight_amount
                    patientData['weight_amount_saved'] =
                        healthRecord.weight_amount > 0
                    patientData['weight_feeling'] = healthRecord.weight_feeling
                    patientData['weight_feeling_saved'] =
                        healthRecord.weight_feeling != ''
                    patientData['weight_comment'] = healthRecord.weight_comment
                    patientData['weight_comment_saved'] =
                        healthRecord.weight_comment != ''

                    patientData['dose_insulin_amount'] =
                        healthRecord.dose_insulin_amount
                    patientData['dose_insulin_amount_saved'] =
                        healthRecord.dose_insulin_amount > 0
                    patientData['dose_insulin_feeling'] =
                        healthRecord.dose_insulin_feeling
                    patientData['dose_insulin_feeling_saved'] =
                        healthRecord.dose_insulin_feeling != ''
                    patientData['dose_insulin_comment'] =
                        healthRecord.dose_insulin_comment
                    patientData['dose_insulin_comment_saved'] =
                        healthRecord.dose_insulin_comment != ''

                    patientData['exercise_amount'] =
                        healthRecord.exercise_amount
                    patientData['exercise_amount_saved'] =
                        healthRecord.exercise_amount > 0
                    patientData['exercise_feeling'] =
                        healthRecord.exercise_feeling
                    patientData['exercise_feeling_saved'] =
                        healthRecord.exercise_feeling != ''
                    patientData['exercise_comment'] =
                        healthRecord.exercise_comment
                    patientData['exercise_comment_saved'] =
                        healthRecord.exercise_comment != ''

                    if (healthRecord.blood_glucose_amount > 0) {
                        countSavedData++
                    }
                    if (healthRecord.weight_amount > 0) {
                        countSavedData++
                    }
                    if (healthRecord.dose_insulin_amount > 0) {
                        countSavedData++
                    }
                    if (healthRecord.exercise_amount > 0) {
                        countSavedData++
                    }
                }
            })
            patientData['count_saved_data'] = countSavedData

            // Search for clinician related to the found patient
            // Reference: https://stackoverflow.com/questions/65863539/how-to-query-for-sub-document-in-an-array-with-mongoose
            const clinician = await Clinician.find({
                patient_list: { $elemMatch: { patient_id: patient._id } },
            })

            if (!clinician) {
                // No clinician found in database
                res.render(fileNotFoundStatus)
                return
            }

            // Found clinician
            const clinicianName =
                clinician[0].given_name + ' ' + clinician[0].family_name
            console.log('clinicianName = ' + clinicianName)

            // Search for patient's data from the related clinician model
            // Reference: https://stackoverflow.com/questions/21113543/mongodb-get-subdocument
            const dataFromClinician = await Clinician.aggregate([
                    { $unwind: '$patient_list' },
                    { $match: { 'patient_list.patient_id': patient._id } },
                    {
                        $project: {
                            _id: 0,
                            support_msg: '$patient_list.support_msg',
                            health_data_threshold: '$patient_list.health_data_threshold',
                        },
                    },
                ])
                // Put patient's data get from clinician model into the patientData object to be used in PatientUI
            patientData['clinicianName'] = clinicianName
            patientData['dataFromClinician'] = dataFromClinician

            // Check from health_data_threshold info to indicate how many input section to be displayed on patient's screen
            const healthDataThreshold =
                dataFromClinician[0].health_data_threshold
            healthDataThreshold.forEach(function(threshold) {
                const endDate = threshold.end_date

                if (!endDate) {
                    // End date is set as null: current threshold data
                    // Put the flag of information that patient need to input in the patientData object
                    patientData['bgl_flag'] = threshold.blood_glucose_flag
                    patientData['weight_flag'] = threshold.weight_flag
                    patientData['insulin_flag'] = threshold.dose_insulin_flag
                    patientData['exercise_flag'] = threshold.exercise_flag

                    if (threshold.blood_glucose_flag) {
                        countRequiredData++
                    }
                    if (threshold.weight_flag) {
                        countRequiredData++
                    }
                    if (threshold.dose_insulin_flag) {
                        countRequiredData++
                    }
                    if (threshold.exercise_flag) {
                        countRequiredData++
                    }
                }
            })
            patientData['count_required_data'] = countRequiredData
            patientData['over_input_from_setting'] = countSavedData > countRequiredData

            // Calculate engagement rate of the patient
            const engagementRate = await calculatePatientEngagementRate(
                patient._id
            )
            const formatEngagementRate = parseFloat(
                (Math.round(engagementRate * 100) / 100).toFixed(2)
            )
            patientData['engagement_rate'] = formatEngagementRate
            patientData['engagement_badge'] = formatEngagementRate >= 80
            if (isNaN(patientData["engagement_rate"])) {
                patientData["engagement_rate"] = 0
            }
            const leaderBoardData = await getAllPatientData(patient.screen_name, patientData['engagement_rate'])
            patientData['all_patient'] = leaderBoardData['all_patient']
            patientData['allRate'] = leaderBoardData['allRate']
            patientData['orderOfCurrentPatient'] = leaderBoardData['orderOfCurrentPatient']
            patientData['outTop5'] = leaderBoardData['outTop5']
            patientData['pos0'] = leaderBoardData['pos0']
            patientData['pos1'] = leaderBoardData['pos1']
            patientData['pos2'] = leaderBoardData['pos2']
            patientData['pos3'] = leaderBoardData['pos3']
            patientData['pos4'] = leaderBoardData['pos4']

            let result = await viewData(req, res);

            let patientresultArray = [];
            patientresultArray = result["datas"];

            const parsed = JSON.parse(patientresultArray);
            console.log(parsed);

            parsed.forEach((data) => {
                if ((data._id).toString() == (req.user.patient_id).toString()) {
                    patientData["data"] = data

                }
            });
            let healthDataArr = patientData.data.health_data;


            const dateList = getDateList(10);

            const dataList = { blood_glucose_amount: [], weight_amount: [], dose_insulin_amount: [], exercise_amount: [] };
            var len = dateList.length;


            for (record of healthDataArr) {
                console.log(record)
                var i = 0

                while (i < len) {

                    if (formatDate(record.enter_date) == dateList[i]) {
                        dataList.blood_glucose_amount[i] = record.blood_glucose_amount;
                        dataList.weight_amount[i] = record.weight_amount;
                        dataList.dose_insulin_amount[i] = record.dose_insulin_amount;
                        dataList.exercise_amount[i] = record.exercise_amount;
                    }
                    i++;
                }
            }
            for (i = 0; i < len; i++) {
                if (!dataList.blood_glucose_amount[i]) {
                    dataList.blood_glucose_amount[i] = 0;
                }
            }
            for (i = 0; i < len; i++) {
                if (!dataList.weight_amount[i]) {
                    dataList.weight_amount[i] = 0;
                }
            }
            for (i = 0; i < len; i++) {
                if (!dataList.dose_insulin_amount[i]) {
                    dataList.dose_insulin_amount[i] = 0;
                }
            }
            for (i = 0; i < len; i++) {
                if (!dataList.exercise_amount[i]) {
                    dataList.exercise_amount[i] = 0;
                }
            }


            console.log(dataList)

            patientData["datas"] = JSON.stringify(dataList);
            patientData["dates"] = JSON.stringify(dateList);


            return res.render('home.hbs', {
                patientData: patientData,
                loggedIn: loggedIn,
            })
        } else {
            // Invalid patient's login data, send user back to login page
            return res.redirect('/')
        }
    } catch (err) {
        return next(err)
    }
}

async function getAllPatientData(screen_name, engagement_rate) {


    let allPatient = []
    let allPatientID = await Patient.distinct("_id", {})
    let allPatientData = {}
    let arrId = []

    for (var i = 0; i < allPatientID.length; i++) {
        let id = allPatientID[i].valueOf()
        const patient = await Patient.findById(id).lean()
        allPatient.push(patient.screen_name)
        let result = await calculatePatientEngagementRate(id)
        let format = parseFloat((Math.round(result * 100) / 100).toFixed(2))
        arrId.push(format)
    }

    var dict = new Object();
    for (var i = 0; i < allPatient.length; i++) {
        var key = allPatient[i]
        var value = arrId[i]
        if (!dict[key]) {
            dict[key] = value;
        }
    }

    var items = Object.keys(dict).map(function(key) {
        return [key, dict[key]];
    });

    for (var i = 0; i < items.length; i++) {
        if (isNaN(items[i][1])) {
            items[i][1] = 0
        }
    }

    // Sort the array based on the second element
    items.sort(function(first, second) {
        return second[1] - first[1];
    });

    // Create a new array with only the first 5 items
    //if current user rate is outside of top 5\\
    var arr_name = []
    var arr_score = []
    for (var i = 0; i < items.length; i++) {
        arr_name.push(items[i][0])
        arr_score.push(items[i][1])
    }

    allPatientData["all_patient"] = arr_name
    allPatientData['allRate'] = arr_score
    console.log(allPatientData)
    if (engagement_rate < items[4][1] || engagement_rate == 0) {
        allPatientData['outTop5'] = true
    }

    if (allPatientData['outTop5']) {
        for (var i = 0; i < items.length; i++) {
            if (screen_name.localeCompare(items[i][0]) == 0) {
                allPatientData['orderOfCurrentPatient'] = i + 1
            }
        }
    }

    allPatientData['pos0'] = false
    allPatientData['pos1'] = false
    allPatientData['pos2'] = false
    allPatientData['pos3'] = false
    allPatientData['pos4'] = false

    for (var i = 0; i < 5; i++) {
        if (screen_name.localeCompare(items[i][0]) == 0) {
            let text1 = "pos"
            let text2 = i
            allPatientData[text1.concat(text2)] = true
        }
    }

    return allPatientData
}

// Add a new health_data object to the patient model as saving patient health data record in the DB
const recordHealthData = async(req, res, next) => {
    try {
        // Check valid logged in patient
        if (req.user && req.user.patient_id != '') {
            const patientID = req.user.patient_id

            // Find the specific patient data.
            let thisPatient = await Patient.findOne({ _id: patientID })

            // Get health record id from the input screen (if available)
            let health_record_id = req.body.health_record_id

            // Prepare bgl data for object creation
            let bgl_amount = 0
            let bgl_input_dateTime = null
            if (req.body.bgl_amount > 0) {
                bgl_amount = req.body.bgl_amount
                bgl_input_dateTime = new Date()
            }

            // Prepare weight data for object creation
            let weight_amount = 0
            let weight_input_dateTime = null
            if (req.body.weight_amount > 0) {
                weight_amount = req.body.weight_amount
                weight_input_dateTime = new Date()
            }

            // Prepare insulin data for object creation
            let insulin_amount = 0
            let insulin_input_dateTime = null
            if (req.body.insulin_amount > 0) {
                insulin_amount = req.body.insulin_amount
                insulin_input_dateTime = new Date()
            }

            // Prepare exercise data for object creation
            let exercise_amount = 0
            let exercise_input_dateTime = null
            if (req.body.exercise_amount > 0) {
                exercise_amount = req.body.exercise_amount
                exercise_input_dateTime = new Date()
            }

            // Check whether the today health data object is created
            console.log('health_record_id = ' + health_record_id)
            if (typeof health_record_id !== 'undefined' && health_record_id) {
                // ===== Already have some today health record saved in the DB =====
                // ===== There is an object of today health_data saved in DB, need update data =====
                console.log('Update Approach')
                    // Save blood glucose level input
                    // Reference: https://stackoverflow.com/questions/55841629/mongoose-update-a-field-in-an-object-of-array
                if (bgl_amount > 0) {
                    await Patient.findOneAndUpdate({ _id: thisPatient._id }, {
                        $set: {
                            'health_data.$[el].blood_glucose_amount': bgl_amount,
                            'health_data.$[el].blood_glucose_feeling': req.body.feeling_bgl,
                            'health_data.$[el].blood_glucose_comment': req.body.bgl_comment,
                            'health_data.$[el].blood_glucose_input_time': bgl_input_dateTime,
                        },
                    }, {
                        arrayFilters: [{ 'el._id': health_record_id }],
                        new: true,
                    })
                }

                // Save weight input
                if (weight_amount > 0) {
                    await Patient.findOneAndUpdate({ _id: thisPatient._id }, {
                        $set: {
                            'health_data.$[el].weight_amount': weight_amount,
                            'health_data.$[el].weight_feeling': req.body.feeling_weight,
                            'health_data.$[el].weight_comment': req.body.weight_comment,
                            'health_data.$[el].weight_input_time': weight_input_dateTime,
                        },
                    }, {
                        arrayFilters: [{ 'el._id': health_record_id }],
                        new: true,
                    })
                }

                // Save insulin input
                if (insulin_amount > 0) {
                    await Patient.findOneAndUpdate({ _id: thisPatient._id }, {
                        $set: {
                            'health_data.$[el].dose_insulin_amount': insulin_amount,
                            'health_data.$[el].dose_insulin_feeling': req.body.feeling_insulin,
                            'health_data.$[el].dose_insulin_comment': req.body.insulin_comment,
                            'health_data.$[el].dose_insulin_input_time': insulin_input_dateTime,
                        },
                    }, {
                        arrayFilters: [{ 'el._id': health_record_id }],
                        new: true,
                    })
                }

                // Save exercise input
                if (exercise_amount > 0) {
                    await Patient.findOneAndUpdate({ _id: thisPatient._id }, {
                        $set: {
                            'health_data.$[el].exercise_amount': exercise_amount,
                            'health_data.$[el].exercise_feeling': req.body.feeling_exercise,
                            'health_data.$[el].exercise_comment': req.body.exercise_comment,
                            'health_data.$[el].exercise_input_time': exercise_input_dateTime,
                        },
                    }, {
                        arrayFilters: [{ 'el._id': health_record_id }],
                        new: true,
                    })
                }
            } else {
                // ===== No any today health data record in the DB yet =====
                // ===== Insert new object in the health_data array object =====
                console.log('Insert Approach')
                    // Create a new health_data object and add to the patient model
                    // Reference: https://stackoverflow.com/questions/29984895/how-to-get-the-australian-time-zone-using-javascript-not-jquery
                const newHealthRecord = new HealthData({
                    enter_date: new Date(),
                    blood_glucose_amount: bgl_amount,
                    blood_glucose_feeling: req.body.feeling_bgl,
                    blood_glucose_comment: req.body.bgl_comment,
                    blood_glucose_input_time: bgl_input_dateTime,
                    weight_amount: weight_amount,
                    weight_feeling: req.body.feeling_weight,
                    weight_comment: req.body.weight_comment,
                    weight_input_time: weight_input_dateTime,
                    dose_insulin_amount: insulin_amount,
                    dose_insulin_feeling: req.body.feeling_insulin,
                    dose_insulin_comment: req.body.insulin_comment,
                    dose_insulin_input_time: insulin_input_dateTime,
                    exercise_amount: exercise_amount,
                    exercise_feeling: req.body.feeling_exercise,
                    exercise_comment: req.body.exercise_comment,
                    exercise_input_time: exercise_input_dateTime,
                })
                thisPatient.health_data.push(newHealthRecord)

                // Save the specific patient's health record to database
                await thisPatient.save()
            }

            // Refresh the page to see the recorded data
            return res.redirect('/home')
        } else {
            // Invalid patient's login data, send user back to login page
            return res.redirect('/')
        }
    } catch (err) {
        return next(err)
    }
}



const viewData = async(req, res) => {
    try {
        let result = {}
        const records = await Patient.find({ patient_id: req.user._id }).lean()
        console.log(records)

        result["datas"] = JSON.stringify(records)
        return result


    } catch (err) {
        console.log(err);
        res.send("error happens in viewing history data");
    }



};


module.exports = {
    getPatientDataById,
    recordHealthData,
    viewData,
}