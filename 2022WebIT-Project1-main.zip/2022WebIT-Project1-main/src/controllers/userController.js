// Link to model
const User = require('../models/user')
const { Patient } = require('../models/patientModel')
const { Clinician } = require('../models/clinicianModel')
const { PatientList } = require('../models/clinicianModel')
const { HealthDataThreshold } = require('../models/clinicianModel')
const { ClinicianNote } = require('../models/clinicianModel')
const BSON = require('bson')

// Insert new patient in DB
const createNewPatient = async (req, res, next) => {
    try {
        // Check valid session
        if (req.session.passport && req.session.passport.user != '') {
            // Check valid logged in user
            if (req.user) {
                const inputGivenName = req.body.givenName
                const inputFamilyName = req.body.familyName
                const inputYearOfBirth = req.body.yearOfBirth
                const inputEmail = req.body.email
                const inputScreenName = req.body.screenName
                const inputBriefBio = req.body.briefBio
                let inputSupportMessage = req.body.supportMessage
                const inputBglFlag = req.body.bgl
                let inputBglMin = req.body.bglMin
                let inputBglMax = req.body.bglMax
                const inputWeightFlag = req.body.weight
                let inputWeightMin = req.body.weightMin
                let inputWeightMax = req.body.weightMax
                const inputInsulinFlag = req.body.doit
                let inputInsulinMin = req.body.doitMin
                let inputInsulinMax = req.body.doitMax
                const inputExerciseFlag = req.body.exercise
                let inputExerciseMin = req.body.exerciseMin
                let inputExerciseMax = req.body.exerciseMax
                let inputClinicianNote = req.body.clinicianNote

                console.log('Input New Patient Info')
                console.log('inputGivenName = ' + inputGivenName)
                console.log('inputFamilyName = ' + inputFamilyName)
                console.log('inputYearOfBirth = ' + inputYearOfBirth)
                console.log('inputEmail = ' + inputEmail)
                console.log('inputScreenName = ' + inputScreenName)
                console.log('inputBriefBio = ' + inputBriefBio)
                console.log('inputSupportMessage = ' + inputSupportMessage)
                console.log('inputClinicianNote = ' + inputClinicianNote)

                // Validate is the Screen Name duplicated
                // Find a patient from screen name
                const matchSceenName = await Patient.findOne({
                    screen_name: { $regex: inputScreenName, $options: 'i' },
                })
                if (
                    matchSceenName &&
                    matchSceenName.screen_name.toLowerCase() ===
                        inputScreenName.toLowerCase()
                ) {
                    // Found a duplicated patient's screen name
                    console.log('Error duplicated screen name!')
                    req.flash('messages', {
                        error: 'Duplicated screen name',
                    })

                    console.log(
                        'Error matchSceenName.screen_name = ' +
                            matchSceenName.screen_name
                    )

                    return res.redirect('/registerNewPatient') // Redirect user back to Registration page and Show error message on the screen
                }
                // No duplicated screen name
                // Validation is the Registered Email duplicated, Find user from registered email
                const matchUser = await User.findOne({
                    username: { $regex: inputEmail, $options: 'i' },
                })
                if (
                    matchUser &&
                    matchUser.username.toLowerCase() ===
                        inputEmail.toLowerCase()
                ) {
                    // Found a duplicated registered email
                    console.log('Error duplicated registered email!')
                    req.flash('messages', {
                        error: 'This email is already registered!',
                    })

                    console.log(
                        'Error matchUser.username = ' + matchUser.username
                    )

                    return res.redirect('/registerNewPatient') // Redirect user back to Registration page and Show error message on the screen
                }
                // No duplicated username (email)
                // Insert a new Patient
                const newPatient = new Patient({
                    given_name: inputGivenName,
                    family_name: inputFamilyName,
                    year_birth: inputYearOfBirth,
                    email: inputEmail,
                    screen_name: inputScreenName,
                    brief_bio: inputBriefBio,
                })
                newPatient.save((err, result) => {
                    if (err) {
                        console.log('Error on inserting new patient = ' + err)
                        req.flash('messages', {
                            error: 'Error occur while registering a new patient, please try again later',
                        })
                        return res.redirect('/registerNewPatient')
                    }
                    console.log('Insert new patient result = ' + result)

                    // Insert new patient successfully
                    const newPatientID = result._id
                    console.log('New patient newPatientID = ' + newPatientID)

                    // Insert new user based on the new registered patient data
                    const newPatientEmail = result.email
                    const defaultNewUserPassword =
                        inputScreenName.toLowerCase() + inputYearOfBirth
                    const defaultSecret = 'Diabetes@Home'
                    const defaultNewUserRole = 'patient'
                    User.find({ patient_id: newPatientID }, (err, users) => {
                        if (err || users.length > 0) {
                            console.log(
                                'Error on inserting new user or Duplicated patient ID found'
                            )
                            console.log(err)
                            req.flash('messages', {
                                error: 'Error occur while registerting a new user, please try again later',
                            })
                            return res.redirect('/registerNewPatient')
                        }
                        User.create(
                            {
                                username: newPatientEmail,
                                password: defaultNewUserPassword,
                                secret: defaultSecret,
                                role: defaultNewUserRole,
                                patient_id: new BSON.ObjectId(newPatientID),
                                clinician_id: null,
                            },
                            (err) => {
                                if (err) {
                                    console.log(err)
                                    res.send(err)
                                }
                                console.log('Insert new user successfully')
                            }
                        )
                    })

                    // Insert new user successfully, Register new patient to the responsible clinician
                    // Get the specific clinician data: This step is based on the concept that only clinician can access the patient's registration page
                    const userID = req.session.passport.user
                    User.findOne({ _id: userID }, async (err, user) => {
                        if (err) {
                            console.log('Error on getting a logged in user id')
                            req.flash('messages', {
                                error: 'Error occur while registering a new patient to the assigned clinician, please try again later',
                            })
                            return res.redirect('/registerNewPatient')
                        }
                        const clinicianID = user.clinician_id
                        console.log('clinicianID = ' + clinicianID)

                        let thisClinician = await Clinician.findOne({
                            _id: clinicianID,
                        })

                        if  (inputBglFlag === 'false') {
                            inputBglMin = 0
                            inputBglMax = 0
                        }
                        if  (inputWeightFlag === 'false') {
                            inputWeightMin = 0
                            inputWeightMax = 0
                        }
                        if  (inputInsulinFlag === 'false') {
                            inputInsulinMin = 0
                            inputInsulinMax = 0
                        }
                        if  (inputExerciseFlag === 'false') {
                            inputExerciseMin = 0
                            inputExerciseMax = 0
                        }

                        console.log('inputBglFlag = ' + inputBglFlag)
                        console.log('inputBglMin = ' + inputBglMin + ' vs inputBglMax = ' + inputBglMax)
                        console.log('inputWeightFlag = ' + inputWeightFlag)
                        console.log('inputWeightMin = ' + inputWeightMin + ' vs inputWeightMax = ' + inputWeightMax)
                        console.log('inputInsulinFlag = ' + inputInsulinFlag)
                        console.log('inputInsulinMin = ' + inputInsulinMin + ' vs inputInsulinMax = ' + inputInsulinMax)
                        console.log('inputExerciseFlag = ' + inputExerciseFlag)
                        console.log('inputExerciseMin = ' + inputExerciseMin + ' vs inputExerciseMax = ' + inputExerciseMax)

                        // Register threshold of the registerd patient
                        const newPatientThreshold = new HealthDataThreshold({
                            start_date: new Date(),
                            end_date: null,
                            blood_glucose_flag: inputBglFlag,
                            blood_glucose_min: inputBglMin,
                            blood_glucose_max: inputBglMax,
                            weight_flag: inputWeightFlag,
                            weight_min: inputWeightMin,
                            weight_max: inputWeightMax,
                            dose_insulin_flag: inputInsulinFlag,
                            dose_insulin_min: inputInsulinMin,
                            dose_insulin_max: inputInsulinMax,
                            exercise_flag: inputExerciseFlag,
                            exercise_min: inputExerciseMin, 
                            exercise_max: inputExerciseMax,
                        })

                        const defaultClinicianNote = 'First time register this patient'
                        if (!inputClinicianNote || inputClinicianNote === "") {
                            inputClinicianNote = defaultClinicianNote
                        }
                        // Register clinician note of the registerd patient
                        const newPatientClinicianNote = ClinicianNote({
                            enter_date_time: new Date(),
                            note: inputClinicianNote,
                        })

                        const defaultSupportMsg =
                            'Your clinician will message to you soon :)'
                        if (!inputSupportMessage || inputSupportMessage === "") {
                            inputSupportMessage = defaultSupportMsg
                        }
                        // Register general mapping between clinician and patient
                        const newPatientInfo = new PatientList({
                            patient_id: newPatientID,
                            support_msg: inputSupportMessage,
                            clinician_note: newPatientClinicianNote,
                            health_data_threshold: newPatientThreshold,
                        })
                        thisClinician.patient_list.push(newPatientInfo)

                        // Save the new patient's info to database in the clinician model
                        await thisClinician.save()
                        console.log(
                            'Register new patient to the responsible clinician successfully'
                        )

                        req.flash('messages', {
                            success: 'Register new patient successfully',
                        })
                        return res.redirect('/registerNewPatient')
                    })
                })
            } else {
                // Invalid login data, send user back to login page
                return res.redirect('/')
            }
        } else {
            // Invalid login data, send user back to login page
            return res.redirect('/')
        }
    } catch (err) {
        return next(err)
    }
}

// Get user's information from DB
const updatePassword = async (req, res, next) => {
    try {
        // Check valid session
        if (req.session.passport && req.session.passport.user != '') {
            // Check valid logged in user
            if (req.user) {
                const loggedIn = req.session.loggedIn
                const userID = req.session.passport.user
                const inputCurrentPwd = req.body.currentPwd
                const inputNewPwd = req.body.newPwd

                console.log('Input Current Password')
                console.log('inputCurrentPwd = ' + inputCurrentPwd)

                // Get current user's data from DB
                // Reference: https://stackoverflow.com/questions/14588032/mongoose-password-hashing
                User.findOne({ _id: userID }, function (err, user) {
                    if (err) {
                        throw err
                    }

                    // Validate input of current password with the stored value on Server side
                    user.verifyPassword(inputCurrentPwd, function (err, valid) {
                        if (err) {
                            throw err
                        }

                        console.log(inputCurrentPwd + ' = ', valid)

                        if (!valid) {
                            // Invalid inputed Current Password
                            // Reference: https://stackoverflow.com/questions/50115625/flash-message-on-redirect-express
                            console.log('Error Incorrect Current Password!')
                            req.flash('messages', {
                                error: 'Incorrect Current Password',
                            })
                            return res.redirect('/changepwd') // Redirect user back to Change Password page and Show error message on the screen
                        } else {
                            // Valid inputed Current Password
                            // Reference: https://stackoverflow.com/questions/23968909/modify-password-with-expressjs-mongoose-passport-local
                            user.password = inputNewPwd // Update user's password to be the new password
                            user.update_date = new Date()
                            user.save(function (err) {
                                if (err) {
                                    console.log(
                                        'Error while changing password!'
                                    )
                                    return next(err)
                                } else {
                                    console.log('Change password successfully!')
                                    req.flash('messages', {
                                        success: 'Change password successfully',
                                    })
                                    return res.redirect('/changepwd') // Update password successfully and Show success message on the screen
                                }
                            })
                        }
                    })
                })
            } else {
                // Invalid login data, send user back to login page
                return res.redirect('/')
            }
        } else {
            // Invalid login data, send user back to login page
            return res.redirect('/')
        }
    } catch (err) {
        return next(err)
    }
}

module.exports = {
    createNewPatient,
    updatePassword,
}
