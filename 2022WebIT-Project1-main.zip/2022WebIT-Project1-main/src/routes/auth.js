const passport = require('passport')
const express = require('express')
const router = express.Router()
const userController = require('../controllers/userController')
const fileNotFoundStatus = 404

// Authentication middleware
const isAuthenticated = (req, res, next) => {
    // If user is not authenticated via passport, redirect to login page
    if (!req.isAuthenticated()) {
        return res.redirect('/login')
    }
    // Otherwise, proceed to next middleware function
    return next()
}

// Caching disabled for every route
// Reference: https://stackoverflow.com/questions/6096492/node-js-and-express-session-handling-back-button-problem
router.use(function (req, res, next) {
    res.set(
        'Cache-Control',
        'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0'
    )
    next()
})

// Login page (with failure message displayed upon login failure)
router.get('/login', (req, res) => {
    res.render('login', { flash: req.flash('error'), title: 'Login' })
})

// Handle login
router.post(
    '/login',
    passport.authenticate('local', {
        successRedirect: '/', // Login was successful, send user to home page
        failureRedirect: '/login', // If bad login, send user back to login page
        failureFlash: true,
    })
)

// Main page which requires login to access
// Note use of authentication middleware here
// Reference: https://stackoverflow.com/questions/26746730/express-js-is-it-possible-to-pass-an-object-to-a-redirect-like-it-is-with-res-r
router.get('/', isAuthenticated, (req, res) => {
    req.session.loggedIn = true // Set variable for checking logged in status in the session

    const userRole = req.user.role
    if (userRole === 'clinician') {
        // Link to clinician router
        const clinicianRouter = require('./clinicianRouter')
        router.use('/clinician', clinicianRouter)

        // Redirect users with 'clinician' role to clinician' home page
        res.redirect('/clinician')
    } else {
        // Link to patient router
        const patientRouter = require('./patientRouter')
        router.use('/home', patientRouter)

        // Redirect users with 'patient' role to patient' home page
        res.redirect('/home')
    }
})

// Handle logout
router.post('/logout', (req, res) => {
    req.logout() // Kill the session
    req.session.loggedIn = false // Reset logged in status in the session when logout
    res.redirect('/') // Redirect user to Home page, which will bounce them to Login page
})

// Handle changing password: Allow only authorized user can access the change password page
router.get('/changepwd', isAuthenticated, (req, res) => {
    const userRole = req.user.role
    const loggedIn = req.session.loggedIn

    if (userRole === 'clinician') {
        // Link to change password page for clinician
        res.render('clinicianChangePassword.hbs', {
            loggedIn: loggedIn,
            flash: req.flash('messages'),
            title: 'Change Password',
        })
    } else {
        // Link to change password page for patient
        res.render('changePasswordPatient.hbs', {
            loggedIn: loggedIn,
            flash: req.flash('messages'),
            title: 'Change Password',
        })
    }
})

// Handle changing password: Submit form for updating new password
router.post('/changepwd', userController.updatePassword)

// Handle register new patient: Allow only authorized user can access the registration page
router.get('/registerNewPatient', isAuthenticated, (req, res) => {
    const userRole = req.user.role
    const loggedIn = req.session.loggedIn

    if (userRole === 'clinician') {
        // Link to change password page for clinician
        res.render('registerNewPatient.hbs', {
            loggedIn: loggedIn,
            flash: req.flash('messages'),
            title: 'Register New Patient',
        })
    } else {
        res.render(fileNotFoundStatus)
    }
})

// Handle register new patient: Submit form for inserting new patient
router.post('/registerNewPatient', userController.createNewPatient)

// Handle accessing patient'info page on clinician UI
router.get('/dashboard/:patient_id', isAuthenticated, (req, res) => {
    const userRole = req.user.role
    const workingRoute = '/clinician/dashboard/' + req.params.patient_id
    console.log("===== Do authentication from clicking link on dashboard =====")
    console.log("workingRoute = " + workingRoute)
    if (userRole === 'clinician') {
        // Link to clinician router
        const clinicianRouter = require('./clinicianRouter')
        router.use(workingRoute, clinicianRouter)

        // Redirect users with 'clinician' role to clinician' home page
        res.redirect(workingRoute)
    } else {
        res.render(fileNotFoundStatus)
    }
})

// Handle accessing all patient health record on clinician UI
router.get('/allData', isAuthenticated, (req, res) => {
    const userRole = req.user.role
    const workingRoute = '/clinician/allData'
    console.log("===== Do authentication from clicking view all patient's health data =====")
    if (userRole === 'clinician') {
        // Link to clinician router
        const clinicianRouter = require('./clinicianRouter')
        router.use(workingRoute, clinicianRouter)

        // Redirect users with 'clinician' role to clinician' home page
        res.redirect(workingRoute)
    } else {
        res.render(fileNotFoundStatus)
    }
})

// Handle accessing all patient's comment on clinician UI
router.get('/allComments', isAuthenticated, (req, res) => {
    const userRole = req.user.role
    const workingRoute = '/clinician/allComments'
    console.log("===== Do authentication from clicking view all patient's comments =====")
    if (userRole === 'clinician') {
        // Link to clinician router
        const clinicianRouter = require('./clinicianRouter')
        router.use(workingRoute, clinicianRouter)

        // Redirect users with 'clinician' role to clinician' home page
        res.redirect(workingRoute)
    } else {
        res.render(fileNotFoundStatus)
    }
})

module.exports = router