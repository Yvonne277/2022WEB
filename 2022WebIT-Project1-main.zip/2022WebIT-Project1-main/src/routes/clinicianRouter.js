const express = require('express')

// Create router object
const clinicianRouter = express.Router()

// Require controller
const clinicianController = require('../controllers/clinicianController')

// Test getting today patient's health data from clinician id
clinicianRouter.get(
    '/',
    clinicianController.getTodayPatientHealthDataFromClinicianId
)
/*
// Test getting patient's general information from patient id
clinicianRouter.get(
    '/clinician/dashboard/:patient_id',
    clinicianController.getPatientGeneralInfoFromClinicianId
)
*/
// Test postting patient's general info from patient id
clinicianRouter.post(
    '/dashboard/:patient_id',
    clinicianController.editGeneralInfo
)
// clicking name and will go to patient's details page
clinicianRouter.get(
    '/dashboard/:patient_id', clinicianController.getPatientGeneralInfoFromClinicianId);
// Test getting patient's all health data from patient id
clinicianRouter.get(
    '/allData',
    clinicianController.getPatientHealthDataFromClinicianId
)
// Test getting patient's all comments from patient id
clinicianRouter.get(
    '/allComments',
    clinicianController.getPatientCommentsFromClinicianId
)

// Export the router
module.exports = clinicianRouter
