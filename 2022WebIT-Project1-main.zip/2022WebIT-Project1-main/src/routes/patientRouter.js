const express = require('express')

// Create router object
const patientRouter = express.Router()

// Require controller
const patientController = require('../controllers/patientController')

// Add a route to handle the GET request for today health record of a specific patient
patientRouter.get('/', patientController.getPatientDataById)

// Add a route to view history data
patientRouter.get('/view', patientController.viewData)

// add a new JSON object to the database
patientRouter.post('/', patientController.recordHealthData)

// Export the router
module.exports = patientRouter